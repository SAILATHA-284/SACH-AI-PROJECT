
document.getElementById("check").onclick = async () => {
  const username = document.getElementById("username").value.trim();
  const resultDiv = document.getElementById("result");

  if (!username) {
    resultDiv.innerText = "Please enter a username.";
    return;
  }

  try {
    const res = await fetch("http://localhost:5000/predict-twitter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username })
    });

    const data = await res.json();
    if (data.error) {
      resultDiv.innerText = `Error: ${data.error}`;
    } else {
      resultDiv.innerText = data.is_fake
        ? `⚠️ Fake (${data.confidence}%)`
        : `✅ Real (${data.confidence}%)`;
    }
  } catch (e) {
    resultDiv.innerText = "Failed to connect to the backend.";
  }
};
